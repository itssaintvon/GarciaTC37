<?php

namespace App\Controllers;

class Customers extends BaseController
{
    public function index(): string
    {
        $customers = [
            ['id' => 1, 'name' => 'Juan Dela Cruz', 'email' => 'juan@example.com'],
            ['id' => 2, 'name' => 'Maria Santos', 'email' => 'maria@example.com'],
            ['id' => 3, 'name' => 'Pedro Reyes', 'email' => 'pedro@example.com'],
        ];

        return view('customers/customers', [
            'title' => 'Customer Accounts',
            'customers' => $customers,
        ]);
    }
}

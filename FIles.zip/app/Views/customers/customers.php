<?= $this->include('layout/header') ?>
<div class="page-card">
    <h1 class="page-title"><?= esc($title ?? 'Customer Accounts') ?></h1>
    <p class="page-description">List of registered customers.</p>
    <div class="table-wrapper">
        <table class="data-table">
            <thead><tr><th>ID</th><th>Name</th><th>Email</th></tr></thead>
            <tbody>
                <?php foreach ($customers ?? [] as $customer): ?>
                    <tr>
                        <td><?= esc($customer['id']) ?></td>
                        <td><?= esc($customer['name']) ?></td>
                        <td><?= esc($customer['email']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->include('layout/footer') ?>

<?php

namespace App\Controllers;

class Users extends BaseController
{
    public function index(): string
    {
        $users = [
            ['id' => 1, 'name' => 'Admin User', 'role' => 'Administrator'],
            ['id' => 2, 'name' => 'Cashier User', 'role' => 'Cashier'],
            ['id' => 3, 'name' => 'Manager User', 'role' => 'Manager'],
        ];

        return view('users/users', [
            'title' => 'User Accounts',
            'users' => $users,
        ]);
    }
}

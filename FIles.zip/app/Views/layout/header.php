<?php
$uriPath = trim(service('uri')->getPath(), '/');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? $page_title ?? 'GarciaTC37') ?></title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, Helvetica, sans-serif; background: #f4f6f9; color: #222; min-height: 100vh; }
        .site-header { background: #1f2937; color: white; padding: 0 30px; box-shadow: 0 3px 10px rgba(0,0,0,.12); }
        .header-container { max-width: 1200px; margin: 0 auto; min-height: 70px; display: flex; align-items: center; justify-content: space-between; gap: 20px; }
        .brand { color: white; text-decoration: none; font-size: 24px; font-weight: 700; letter-spacing: .5px; }
        .brand span { color: #60a5fa; }
        .main-nav { display: flex; align-items: center; gap: 8px; }
        .main-nav a { color: #d1d5db; text-decoration: none; padding: 11px 15px; border-radius: 8px; font-size: 15px; font-weight: 500; transition: .2s ease; }
        .main-nav a:hover { background: #374151; color: white; }
        .main-nav a.active { background: #2563eb; color: white; }
        .page-container { max-width: 1200px; margin: 0 auto; padding: 40px 25px; min-height: calc(100vh - 140px); }
        .page-card { background: white; border-radius: 14px; padding: 30px; box-shadow: 0 4px 15px rgba(0,0,0,.07); }
        .page-title { font-size: 30px; margin-bottom: 10px; color: #1f2937; }
        .page-description { color: #6b7280; margin-bottom: 25px; line-height: 1.6; }
        .btn { display: inline-block; background: #2563eb; color: white; text-decoration: none; padding: 11px 18px; border-radius: 8px; font-size: 14px; border: none; cursor: pointer; transition: .2s ease; }
        .btn:hover { background: #1d4ed8; }
        .table-wrapper { width: 100%; overflow-x: auto; }
        .data-table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        .data-table th, .data-table td { padding: 14px; text-align: left; border-bottom: 1px solid #e5e7eb; }
        .data-table th { background: #f9fafb; color: #374151; font-weight: 600; }
        .data-table tr:hover { background: #f9fafb; }
        .site-footer { background: #111827; color: #9ca3af; padding: 25px 30px; }
        .footer-container { max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; gap: 20px; }
        .footer-text { font-size: 14px; }
        .footer-nav { display: flex; gap: 18px; }
        .footer-nav a { color: #9ca3af; text-decoration: none; font-size: 14px; }
        .footer-nav a:hover { color: white; }
        @media (max-width: 768px) {
            .site-header { padding: 15px 20px; }
            .header-container { flex-direction: column; align-items: stretch; }
            .brand { text-align: center; }
            .main-nav { justify-content: center; flex-wrap: wrap; }
            .main-nav a { font-size: 14px; padding: 9px 12px; }
            .page-container { padding: 25px 15px; }
            .page-card { padding: 20px; }
            .page-title { font-size: 25px; }
            .footer-container { flex-direction: column; text-align: center; }
            .footer-nav { flex-wrap: wrap; justify-content: center; }
        }
        @media (max-width: 480px) {
            .main-nav { display: grid; grid-template-columns: repeat(2, 1fr); width: 100%; }
            .main-nav a { text-align: center; }
            .page-card { padding: 18px; }
            .page-title { font-size: 22px; }
        }
    </style>
</head>
<body>
<header class="site-header">
    <div class="header-container">
        <a href="/" class="brand">Garcia<span>TC37</span></a>
        <nav class="main-nav" aria-label="Main navigation">
            <a href="/" class="<?= $uriPath === '' ? 'active' : '' ?>">Home</a>
            <a href="/about" class="<?= $uriPath === 'about' ? 'active' : '' ?>">About</a>
            <a href="/customers" class="<?= $uriPath === 'customers' ? 'active' : '' ?>">Customers</a>
            <a href="/users" class="<?= $uriPath === 'users' ? 'active' : '' ?>">Users</a>
        </nav>
    </div>
</header>
<main class="page-container">

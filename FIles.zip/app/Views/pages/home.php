<?= $this->include('layout/header') ?>
<div class="page-card">
    <h1 class="page-title">Welcome to GarciaTC37</h1>
    <p class="page-description">Welcome to our CodeIgniter website. Use the navigation above to explore the different sections.</p>
    <a href="/customers" class="btn">View Customers</a>
</div>
<?= $this->include('layout/footer') ?>

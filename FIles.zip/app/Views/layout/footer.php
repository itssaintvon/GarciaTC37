</main>
<footer class="site-footer">
    <div class="footer-container">
        <div class="footer-text">&copy; <?= date('Y') ?> GarciaTC37. All rights reserved.</div>
        <nav class="footer-nav" aria-label="Footer navigation">
            <a href="/">Home</a>
            <a href="/about">About</a>
            <a href="/customers">Customers</a>
            <a href="/users">Users</a>
        </nav>
    </div>
</footer>
</body>
</html>

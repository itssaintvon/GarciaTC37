<?= $this->include('layout/header') ?>
<div class="page-card">
    <h1 class="page-title">About Us</h1>
    <p class="page-description">This website is created using CodeIgniter 4 and follows the Model-View-Controller architecture.</p>
    <p class="page-description">The navigation header and footer are shared across all pages using the layout system.</p>
</div>
<?= $this->include('layout/footer') ?>

<?= $this->include('layout/header') ?>
<div class="page-card">
    <h1 class="page-title"><?= esc($title ?? 'User Accounts') ?></h1>
    <p class="page-description">List of users registered in the system.</p>
    <div class="table-wrapper">
        <table class="data-table">
            <thead><tr><th>ID</th><th>Name</th><th>Role</th></tr></thead>
            <tbody>
                <?php foreach ($users ?? [] as $user): ?>
                    <tr>
                        <td><?= esc($user['id']) ?></td>
                        <td><?= esc($user['name']) ?></td>
                        <td><?= esc($user['role']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->include('layout/footer') ?>
